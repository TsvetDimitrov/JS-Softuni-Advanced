export function setupDetails(section, navigation){
    return showDetails;

    async function showDetails(){
        return section
    }
}