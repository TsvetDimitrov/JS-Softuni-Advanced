export function setupRegister(section, navigation){
    return showRegister;

    async function showRegister(){
        return section
    }
}