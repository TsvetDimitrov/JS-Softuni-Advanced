export function setupCreate(section, navigation){
    return showCreate;

    async function showCreate(){
        return section
    }
}