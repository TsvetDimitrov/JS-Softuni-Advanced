export function setupLogin(section, navigation){
    return showLogin;

    async function showLogin(){
        return section
    }
}